//Coding Practices: https://www.geeksforgeeks.org/7-common-programming-principles-that-every-developer-must-follow/

//Phase 1 libraries
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <set>


//Phase 2 libraries
#include <random>
#include <vector>

using namespace std;

//Phase 1 (Gather the data)
int checkTheArguments(string fileName, int numOfClusters, int maxIterations, double convergenceThreshold, int numOfRuns);
vector<vector<double>> readData(string fileName, int& numOfInstances, int& sizeOfInstances);
vector<vector<double>> setClusters(vector<vector<double>>& data, int numOfClusters);


//Phase 2 (Run the K-Means)
double runIterations(int& maxIterations, double& convergenceThreshold, vector<vector<double>>& clusters, vector<vector<double>>& data);
double calculateSquaredDistance(const vector<double>& x, const vector<double>& c, const double& closestDist);

int main(int argc, char* argv[])
{
    string fileName;
    int numOfClusters = -1;
    int maxIterations = -1;
    double convergenceThreshold = -1;
    int numOfRuns = -1;



    // make sure there are 5 arguments
    if (argc != 6)
    {
        cout << "Usage: <F> <K> <I> <T> <R>" << endl;
        cout << "F: Name of the data file" << endl;
        cout << "K: Number of clusters (positive integer greater than 1)" << endl;
        cout << "I: Maximum number of iterations (positive integer)" << endl;
        cout << "T: Convergence threshold (non-negative real number)" << endl;
        cout << "R: Number of runs (positive integer)" << endl;
        return 1;
    }

    // collect the data from arguments
    fileName = argv[1];
    numOfClusters = stoi(argv[2]);
    maxIterations = stoi(argv[3]);
    convergenceThreshold = stod(argv[4]);
    numOfRuns = stoi(argv[5]);

    //check the data
    int result = checkTheArguments(fileName, numOfClusters, maxIterations, convergenceThreshold, numOfRuns);

    if (result == 1) {
        //error
        return 1;
    }

    // Play with the data here!
    int sizeOfInstances, numOfInstances;
    //Read the data from the file
    vector<vector<double>> data = readData(fileName, numOfInstances, sizeOfInstances);

    vector<vector<double>> clusters;
    double bestSSE = 0;
    int bestRun = 0;
    //run for the number of runs
    for (int i = 1; i <= numOfRuns; i++) {
        //obtain clusters
        clusters = setClusters(data, numOfClusters);

        //phase 2
        cout << "Run " << i << endl;
        cout << "___________" << endl;
        //run the iterations and display the SSE
        double finalSSE = runIterations(maxIterations, convergenceThreshold, clusters, data);
        if (bestSSE == 0 || finalSSE < bestSSE) {
            bestSSE = finalSSE;
            bestRun = i;
        }
    }
    //Print out what the best run was
    cout << "Best Run: " << bestRun << endl;
    cout << "SSE: " << bestSSE << endl;
    
    return 0;
}

//makes sure the arguments are valid
int checkTheArguments(string fileName, int numOfClusters, int maxIterations, double convergenceThreshold, int numOfRuns) {
    try
    {
        // Validate the arguments
        ifstream file(fileName);
        if (!file)
        {
            throw invalid_argument(("File: " + fileName + " does not exist.").c_str());
        }
        file.close();

        if (numOfClusters <= 1)
        {
            throw invalid_argument("Number of clusters (K) must be greater than 1.");
        }
        if (maxIterations <= 0)
        {
            throw invalid_argument("Maximum number of iterations (I) must be positive.");
        }
        if (convergenceThreshold < 0)
        {
            throw invalid_argument("Convergence threshold (T) cannot be negative.");
        }
        if (numOfRuns <= 0)
        {
            throw invalid_argument("Number of runs (R) must be positive.");
        }

    }
    catch (const invalid_argument& e) {
        cout << "Error: " << e.what() << endl;
        return 1;
    }
    catch (const exception& e) {
        cout << "Unexpected error: " << e.what() << endl;
        return 1;
    }
}
//reads the data from the file
vector<vector<double>> readData(string fileName, int& numOfInstances, int& sizeOfInstances) {
    ifstream file(fileName);
    string line;

    // Read the first line to get the number of lines and the size of each line
    getline(file, line);
    stringstream ss(line);
    ss >> numOfInstances >> sizeOfInstances;

    // Create a 2D vector with numOfInstances rows and sizeOfInstances columns
    vector<vector<double>> data(numOfInstances, vector<double>(sizeOfInstances));

    int dataIndex = 0;

    // Go through the rest of the file and store the data
    while (getline(file, line) && dataIndex < numOfInstances) {
        stringstream point(line);
        double newDouble;
        int index = 0;

        while (point >> newDouble && index < sizeOfInstances) {
            data[dataIndex][index] = newDouble;
            index++;
        }
        dataIndex++;
    }

    file.close();
    return std::move(data);
}
//sets up the clusters
vector<vector<double>> setClusters(vector<vector<double>>& data, int numOfClusters) {
    //Randomly pick data for the clusters
    vector<vector<double>> clusters(numOfClusters, vector<double>(data[0].size()));

    // Use random_device for a better random seed
    random_device rd;
    mt19937 gen(rd());  // Initialize random number generator with seed

    // Make a set for the data psoition
    set<vector<double>> clusterData;

    int numOfInstances = data.size();
    for (int i = 0; i < numOfClusters; i++) {
        int randomNum;
        do {
            randomNum = gen() % numOfInstances; 
        } while (clusterData.find(data[randomNum]) != clusterData.end());
        clusterData.insert(data[randomNum]);


        
        //save cluster
        clusters[i] = data[randomNum];
        
    }

    return clusters;
}

//Run through the Iterations | & are to save on memory managment and speed
double runIterations(int& maxIterations, double& convergenceThreshold, vector<vector<double>>& clusters, vector<vector<double>>& data) {
    
    
    double oldSSE = 0;
    int numOfInstances = data.size();
    int numOfClusters = clusters.size();
    int sizeOfInstances = data[0].size();

    //data for the loop | Initialize here to save on memory allocation
    vector<vector<double>> newClusters(numOfClusters, vector<double>(sizeOfInstances));
    vector<int> amountOfData(numOfClusters);

    //i is the iteration we are on
    for (int i = 1; i <= maxIterations; i++) {
        double SSE = 0.0;
        //generate new clusters by taking the average of the seperated data points
        //reset the newClusters list
        for (auto& cluster : newClusters) {
            fill(cluster.begin(), cluster.end(), 0.0);
        }
        //make a vector to keep track of the number of data points in each cluster
        fill(amountOfData.begin(), amountOfData.end(), 0);

        //An Iteration
        for (int j = 0; j < numOfInstances; j++) {
            //Find which cluster is closer, initializing with the first cluster distance
            int closest = 0;
            // -1 means that there is no closest distance yet
            double closestDist = calculateSquaredDistance(data[j], clusters[0], -1);
            // // Loop through all clusters to find the closest
            for (int h = 1; h < numOfClusters; h++) {  // Start from 1 since 0 is already checked
                double dist = calculateSquaredDistance(data[j], clusters[h], closestDist);
                if (dist < closestDist) {
                    closestDist = dist;  // Update closest distance
                    closest = h;         // Update closest cluster index
                }
            }

            // Calculate the SSE
            SSE += closestDist;
            
            //generate new clusters
            //add the data to the cluster
            for (int k = 0; k < sizeOfInstances; k++) {
                newClusters[closest][k] += data[j][k];
            }

            //update the number of data points for this cluster
            amountOfData[closest] += 1;
        }

            
        
        
        //check if the convergenceThreshold is reached and kill the run if so
        if ((oldSSE - SSE) / oldSSE < convergenceThreshold && oldSSE != 0) {
            break;
        }
        cout << "Iteration " << i << ": " << SSE << endl;
        oldSSE = SSE;


        //once all of the data has been added together find the average for each cluster
        //Also handle singleton clusters
        for (int i = 0; i < numOfClusters; i++) {
            if (amountOfData[i] != 1) {
                //is not a singleton cluster
                for (int j = 0; j < sizeOfInstances; j++) {
                    if (amountOfData[i] > 0)
                        newClusters[i][j] /= amountOfData[i];
                }
                //save the new clusters as the old
                clusters[i] = newClusters[i];
            }
            else {
                //Is a singleton cluster
                // Find the point contributing most to the SSE
                int maxErrorPointIndex = -1;
                double maxError = -1;
                for (int j = 0; j < numOfInstances; j++) {
                    double dist = calculateSquaredDistance(data[j], clusters[i], -1);
                    if (dist > maxError) {
                        maxError = dist;
                        maxErrorPointIndex = j;
                    }
                }
                // Reassign the cluster center to this point
                if (maxErrorPointIndex != -1) {
                    clusters[i] = data[maxErrorPointIndex];
                }
            }
        }
        
    }
    return oldSSE;
}
//returns a squared distance and quits if the closest Dist is exceeded to save on time (& avoids making copies to make it faster)
double calculateSquaredDistance(const vector<double>& x, const vector<double>& c, const double& closestDist) {
    double distance = 0;
    for (int i = 0; i < x.size(); i++) {
        double diff = x[i] - c[i];
        //add the squared difference
        distance += diff * diff;
        if (closestDist >= 0 && closestDist < distance)
            break;
    }
    return distance;  // Return the squared distance
}
